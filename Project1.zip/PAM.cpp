#include "PAM.h"



PAM::PAM(std::string fname)
{
	std::ifstream image(fname, std::ios::binary);
	if (!image) throw InputException();
	else
	{
		uint16_t id;
		image.read((char*)&id, 2);
		if (id != 0x3750) throw FileTypeException();
		else {
			uint8_t dot;
			image.read((char*)&dot, 1);
			uint32_t res1;
			image.read((char*)&res1, 4);
			uint16_t res2;
			image.read((char*)&res2, 2);
			uint8_t wd;
			std::string pom = "";
			do {
				image.read((char*)&wd, 1);
				if (wd != dot) {
					pom += wd;
				}
			} while (wd != dot);
			width = atoi(pom.c_str());

			image.read((char*)&res1, 4);
			image.read((char*)&res2, 2);
			uint8_t res3;
			image.read((char*)&res3, 1);
			uint8_t hg;
			pom = "";
			do {
				image.read((char*)&hg, 1);
				if (hg != dot) {
					pom += hg;
				}
			} while (hg != dot);
			height = atoi(pom.c_str());
			image.read((char*)&res1, 4);
			image.read((char*)&res2, 2);
			uint8_t dp;
			pom = "";
			do {
				image.read((char*)&dp, 1);
				if (dp != dot) {
					pom += dp;
				}
			} while (dp != dot);
			depth = atoi(pom.c_str());
			image.read((char*)&res1, 4);
			image.read((char*)&res2, 2);
			image.read((char*)&res3, 1);
			uint8_t mv;
			pom = "";
			do {
				image.read((char*)&mv, 1);
				if (mv != dot) {
					pom += mv;
				}
			} while (mv != dot);
			maxval = atoi(pom.c_str());
			image.read((char*)&res1, 4);
			image.read((char*)&res1, 4);
			image.read((char*)&res3, 1);
			uint8_t tt;
			do {
				image.read((char*)&tt, 1);
				if (tt != dot) {
					tuple_type += tt;
				}
			} while (tt != dot);

			image.read((char*)&res1, 4);
			image.read((char*)&res2, 2);
			image.read((char*)&res3, 1);
			pom = "";
			if (depth == 4) {
				while (!image.eof()) {
					uint8_t red;
					image.read((char*)&red, 1);
					uint8_t green;
					image.read((char*)&green, 1);
					uint8_t blue;
					image.read((char*)&blue, 1);
					uint8_t alpha;
					image.read((char*)&alpha, 1);
					Pixel p(red, green, blue, alpha);
					arr.push_back(p);
				}
				arr.erase(arr.end() - 1);
			}
			else {
				if (depth == 3) {
					while (!image.eof()) {
						uint8_t red;
						uint8_t green;
						uint8_t blue;
						image.read((char*)&red, 1);
						image.read((char*)&green, 1);
						image.read((char*)&blue, 1);
						Pixel p(red, green, blue, 255);
						arr.push_back(p);
					}
					arr.erase(arr.end() - 1);
				}
			}

			image.close();
		}
	}
}

void PAM::write(const char* fname) {
	std::ofstream image(fname, std::ios::binary);
	uint16_t id = 0x3750;
	uint8_t dot = 0x0A;
	image.write((char*)&id, 2);
	image.write((char*)&dot, 1);
	std::string let="WIDTH ";
	for (int i = 0; i < let.size(); i++)
		image.write((char *)&let[i], 1);
	char w[10];
	_itoa_s(width, w, 10);
	int i = 0;
	while(w[i]!='\0')
	image.write(&w[i++], 1);

	image.write((char*)&dot, 1);
	let = "HEIGHT ";
	for (int i = 0; i<let.size(); i++)
		image.write((char *)&let[i], 1);
	_itoa_s(height, w, 10);
	i = 0;
	while (w[i] != '\0')
		image.write(&w[i++], 1);

	image.write((char*)&dot, 1);
	let = "DEPTH ";
	for (int i = 0; i < let.size(); i++)
		image.write((char *)&let[i], 1);
	_itoa_s(depth, w, 10);
	i = 0;
	while (w[i] != '\0')
		image.write(&w[i++], 1);

	image.write((char*)&dot, 1);
	let = "MAXVAL ";
	for (int i = 0; i < let.size(); i++)
		image.write((char *)&let[i], 1);
	_itoa_s(maxval, w, 10);
	i = 0;
	while (w[i] != '\0')
		image.write(&w[i++], 1);
	image.write((char*)&dot, 1);

	let = "TUPLTYPE ";
	for (int i = 0; i < let.size(); i++)
		image.write((char *)&let[i], 1);
	for(int j=0; j<tuple_type.size();j++)
	image.write((char*)&tuple_type[j], 1);
	image.write((char*)&dot, 1);

	let = "ENDHDR";
	for (int i = 0; i < let.size(); i++)
		image.write((char *)&let[i], 1);
	image.write((char*)&dot, 1);

	if (depth == 4) {
		for (Pixel i : arr) {
			uint8_t  el = i.Red();
			image.write((char*)&el, 1);
			el = i.Green();
			image.write((char*)&el, 1);
			el = i.Blue();
			image.write((char*)&el, 1); 
			el = i.Alpha() * 255;
			image.write((char*)&el, 1);
		}
	}
	else {
		if (depth == 3) {
			for (Pixel i : arr) {
				uint8_t el = i.Red();
				image.write((char*)&el, 1);
				el = i.Green();
				image.write((char*)&el, 1);
				el = i.Blue();
				image.write((char*)&el, 1);
			}
		}
	}
	image.close();
}

