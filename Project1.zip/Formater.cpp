#include "Formater.h"

std::vector<int> Formater::Header() const {
	std::vector<int> pom;
	pom.push_back(bmpHeader.size_of_file);
	pom.push_back(bmpHeader.off);
	pom.push_back(bmpHeader.size_of_image);
	return pom;
}


void Formater::rowReverse() {
	std::vector<Pixel> ret;
	std::vector<std::vector<Pixel>> pom;
	for (int i = 0; i < height; i++) {
		for (int j = 0; j < width; j++) {
			int pos = i * width + j;
			ret.push_back(arr[pos]);
		}
		pom.insert(pom.begin(), ret);
		ret.clear();
	}
	arr.clear();
	for (std::vector<Pixel> n : pom) {
		for (Pixel px : n)
			arr.push_back(px);
	}
}

Formater::Formater(std::string fname)
{
	std::regex rx("[^\\.]+\\.(.*)");				//Izvlacimo ekstenziju fajla...Citamo do prve tacke, a zatim izdvajamo tri slova koja oznacavaju ekstenziju
	std::smatch result;
	std::string file = fname;
	if (std::regex_match(file, result, rx)) {
		std::string type = result.str(1);
		if (type == "bmp") {
				BMP image(fname);
				arr = image.arr;
				width = image.width;
				height = image.height;
				bmpHeader.size_of_file = image.size_file;
				bmpHeader.size_of_image = image.size_image;
				bmpHeader.bpp = image.bpp;
				bmpHeader.off = image.off;
				if (image.bpp == 32) {
					pamHeader.depth = 4;
					pamHeader.tuple_type = "RGB_ALPHA";
					pamHeader.maxval = 255;
				}
				else {
					pamHeader.depth = 3;
					pamHeader.tuple_type = "RGB";
					pamHeader.maxval = 255;
				}
		}
		else {
			if (type == "pam") {
				PAM image(fname);
				arr = image.arr;
				width = image.width;
				height = image.height;
				rowReverse();
				pamHeader.depth = image.depth;
				pamHeader.maxval = image.maxval;
				pamHeader.tuple_type = image.tuple_type;
				bmpHeader.size_of_image = arr.size() * 4;
				bmpHeader.size_of_file = bmpHeader.size_of_image + 54;
				bmpHeader.off = 54;
				bmpHeader.bpp = (pamHeader.depth == 3) ? 24 : 32;
			}
			if (type == "xml") {
				XML image(fname);
				xmlHeader.layers = image.layers;
				xmlHeader.compOp = image.compOp;
				xmlHeader.selections = image.selections;
			}
		}
		
	}
}

Formater::Formater(std::vector<Pixel> pom, std::vector<int> hed, int w, int h, XMLHeader xml) :arr(pom), width(w), height(h),xmlHeader(xml) {
	bmpHeader.size_of_file = hed[0];
	bmpHeader.off = hed[1];
	bmpHeader.size_of_image = hed[2];
	pamHeader.maxval = 255;
	pamHeader.tuple_type = (pamHeader.depth == 3) ? "RGB" : "RGB_ALPHA";
};

void Formater::write(const char* fname) {
	std::regex rx("[^\\.]*\\.(.*)");
	std::smatch result;
	std::string file = fname;
	if (std::regex_match(file, result, rx)) {
		std::string type = result.str(1);
		if (type == "bmp") {
		//	std::cout << "24 or 32 bit?";
			int b=32;
		//	std::cin >> b;
			BMP image(arr, bmpHeader.size_of_file, width, height, bmpHeader.off, b, bmpHeader.size_of_image);
			image.write(fname);
		}
		else {
			if (type == "pam") {
				rowReverse();
		//		std::cout << "24 or 32 bit?";
				int b=32;
		//		std::cin >> b;
				pamHeader.depth = (b == 24) ? 3 : 4;
				PAM image(width,height,pamHeader.depth,pamHeader.maxval,pamHeader.tuple_type,arr);
				image.write(fname);
			}
			else {
				if (type == "xml") {
					XML image(xmlHeader.layers,xmlHeader.compOp,xmlHeader.selections);
				//	image.write(fname);
				}
			}
		}
	}
}


Formater::~Formater()
{
}