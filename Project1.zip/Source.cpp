#define _CRT_SECURE_NO_WARNINGS
#include "Image.h"
#include <conio.h>

int main(int argc, char ** argv) {


	Image im;
	int menu;
	bool flag=true;				//Oznacava da li su sacuvane promene na slici.

	if (argc < 2) return 0;
	if (argc == 3) {
		
		
        if(atoi(argv[2]) == 0){
            char* pamFile = argv[1];
            im = Image(pamFile, 100);
            char* bmpFile(pamFile);
            int i = 0;
            while (bmpFile[i] != '\0') i++;
            bmpFile[i- 3] = 'b';
            bmpFile[i - 2] = 'm';
            bmpFile[i-1] = 'p';
            //char* help = {};
            //strcpy(help, bmpFile.c_str());
            im.saveAs(bmpFile);
            return 0;
        }
		if (atoi(argv[2])==1) {
			char* xmlFile = argv[1];
			Image image(xmlFile,100);
			image.operation("Composite", 10);
			image.saveSeparateLayers();
		}
		std::cout << (argv[2]=="operate");
	}
	
}
