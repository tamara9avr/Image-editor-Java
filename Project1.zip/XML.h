#pragma once
#include <fstream>
#include <iostream>
#include <vector>
#include "tinystr.h"
#include "tinyxml.h"
#include <regex>
#include "Exceptions.h"


class XML
{
protected:
	std::vector<std::string> layers;
	std::string compOp;
	std::vector<std::string> selections;
	friend class Formater;
public:
	XML(std::string);
	XML() {};
	XML(std::vector<std::string> l, std::string c, std::vector<std::string> sel) :layers(l), compOp(c), selections(sel) {};
	void write();
	~XML();
};

