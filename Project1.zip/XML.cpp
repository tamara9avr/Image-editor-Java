#include "XML.h"



XML::XML(std::string fname)
{
	TiXmlDocument doc(fname.c_str());
	if (!doc.LoadFile()) return;

	TiXmlHandle hDoc(&doc);
	TiXmlElement* pElem;
	TiXmlHandle hRoot(0);


	pElem = hDoc.FirstChild("Data").FirstChild().Element();

	for (pElem; pElem; pElem = pElem->NextSiblingElement())
	{
		std::string pKey = pElem->Value();
		std::string  pText = pElem->GetText();
			if (pKey == "Layer") layers.push_back(pText);
			else if (pKey == "Selection") selections.push_back(pText);
			else if (pKey == "CompositeOperation") compOp = pText;
	}

	
}


void XML::write() {

	TiXmlDocument doc;
	TiXmlDeclaration * decl = new TiXmlDeclaration("1.0", "", "");
	doc.LinkEndChild(decl);

	TiXmlElement * element = new TiXmlElement("Data");
	doc.LinkEndChild(element);

	for (std::string s : layers) {
		TiXmlElement * el = new TiXmlElement("Layer");
		TiXmlText * text = new TiXmlText(s.c_str());
		el->LinkEndChild(text);
		element->LinkEndChild(el);
	}
	for (std::string s : selections) {
		TiXmlElement * el = new TiXmlElement("Selection");
		TiXmlText * text = new TiXmlText(s.c_str());
		el->LinkEndChild(text);
		element->LinkEndChild(el);
	}

		TiXmlElement * el = new TiXmlElement("CompositeOperation");
		TiXmlText * text = new TiXmlText(compOp.c_str());
		el->LinkEndChild(text);
		element->LinkEndChild(el);


	doc.SaveFile("madeByHand22.xml");
}



XML::~XML()
{
}
