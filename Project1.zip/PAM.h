#pragma once
#include <iostream>
#include <fstream>
#include <vector>
#include "Pixel.h"


class PAM
{
protected:
	int height = 0;;
	int width = 0;
	int depth = 0;
	int maxval = 0;
	std::string tuple_type = "";
	std::vector<Pixel> arr;
	friend class Formater;
public:
	PAM(std::string);
	~PAM() {};
	PAM(int w, int h, int d, int m, std::string t, std::vector<Pixel> a) :width(w), height(h), depth(d), maxval(m), tuple_type(t), arr(a) {};
	void write(const char* fname);
	std::vector<Pixel>::iterator begin() { return arr.begin(); }
	std::vector<Pixel>::iterator end() { return arr.end(); }
};

