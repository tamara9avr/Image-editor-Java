#include "BMP.h"
#include "PAM.h"
#include "XML.h"
#include <algorithm>
#include <regex>

struct XMLHeader {								//Isto zaglavlje se koristi kroz ceo projekat
	std::vector<std::string> layers;
	std::string compOp="";
	std::vector<std::string> selections;
};

class Formater
{
	struct BMPHeader {
		int size_of_file;
		int bpp;
		int size_of_image;
		int off;
	};				
										//Odvojeno cuvam zaglavlje za svaki format, zbog bolje citljivosti
	struct PAMHeader {
		int depth;
		int maxval;
		std::string tuple_type;
	};

	int width;
	int height;

	std::vector<Pixel> arr;

	BMPHeader bmpHeader;
	PAMHeader pamHeader;

public:
	
	XMLHeader xmlHeader;

	Formater(std::string);
	Formater(std::vector<Pixel> pom, std::vector<int> hed, int w, int h, XMLHeader xmlHeader);			//Konstruktor koji koristimo za eksportovajne slike.

	void write(const char*);

	int Height()const { return abs(height); }
	int Width()const { return abs(width); }
	std::vector<Pixel> Arr() const { return arr; }
	std::vector<int> Header() const;

	void rowReverse();								//Prilikom citanja i cuvanja PAM formata potrebno je obrnuti redove piksela da bi niz bio isti kao u BMP formatu.

	std::vector<Pixel>::iterator begin() { return arr.begin(); }
	std::vector<Pixel>::iterator end() { return arr.end(); }

	~Formater();
};



