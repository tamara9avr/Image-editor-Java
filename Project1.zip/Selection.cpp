#include "Selection.h"


Selection::Selection(std::string n, std::vector<Rectangle> r) :name(n), arr(r) {
	active = false;
	for (Rectangle r : arr) {
		for (int i = 0; i < r.Height(); i++) {
			for (int j = 0; j < r.Width(); j++) {
				std::pair<int, int> p(r.Position().first + i, r.Position().second + j);
				map[p] = true;
			}
		}
	}
};

void Selection::exportSelection(std::string fname) {
	std::ofstream sel(fname);
	sel << name << std::endl;
	for (Rectangle r : arr) {
		sel << r.Position().first << " " << r.Position().second << " " << r.Width() << " " << r.Height() << std::endl;
	}
	sel.close();
}

Selection::Selection(std::string fname) {
	try {
		std::ifstream sel(fname);
		if (!sel) throw SelectionException();
		sel >> name;
		while (!sel.eof()) {
			int x, y, w, h;
			sel >> x >> y >> w >> h;
			std::pair<int, int> par(x, y);
			Rectangle r(par, w, h);
			arr.push_back(r);
		}
		for (Rectangle r : arr) {
			for (int i = 0; i < r.Height(); i++) {
				for (int j = 0; j < r.Width(); j++) {
					std::pair<int, int> p(r.Position().first + j, r.Position().second + i);
					map[p] = true;
				}
			}
		}
		sel.close();
	}
	catch (SelectionException& se) {
		std::cout << se;
	}
}

Selection::~Selection()
{
}
