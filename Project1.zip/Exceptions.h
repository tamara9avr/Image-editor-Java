#pragma once
#include <iostream>

class InputException {
public:
	InputException() {};
	friend std::ostream& operator<< (std::ostream& os, InputException& ie) {
		return (os << "Error: Can't open file..." << std::endl);
	}
};

class FileTypeException {
public:
	FileTypeException() {};
	friend std::ostream& operator<< (std::ostream& os, FileTypeException& ie) {
		return (os << "Error: Incorrect file type..." << std::endl);
	}
};


class SelectionException {
public:
	SelectionException() {};
	friend std::ostream& operator<< (std::ostream& os, SelectionException& ie) {
		return (os << "Error: can't open selecton file..." << std::endl);
	}
};