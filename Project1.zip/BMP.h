#include "Pixel.h"


class BMP
{
protected:
	uint32_t size_file;
	uint32_t width;
	uint32_t height;
	uint32_t off;
	uint16_t bpp;
	uint32_t size_image;
	std::vector<Pixel> arr;

	friend class Formater;

public:
	BMP(std::string);
	void write(const char*);
	BMP(std::vector<Pixel> pom, uint32_t sf, uint32_t w, uint32_t h, uint32_t of, uint16_t p, uint32_t si):arr(pom),size_file(sf),
		width(w),height(h),off(of),bpp(32),size_image(si) {};
	~BMP() {};
	std::vector<Pixel>::iterator begin() { return arr.begin(); }
	std::vector<Pixel>::iterator end() { return arr.end(); }
};
