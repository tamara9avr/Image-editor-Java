#include "Image.h"


Image::Image(const char * fname, int t)
{
	try {
		Formater f(fname);
		height = f.Height();
		width = f.Width();
		header = f.Header();
	//	if (f.xmlHeader.layers.size() != 0) {
			for (std::string l : f.xmlHeader.layers) {
				addLayer(l, t);
			}
			for(std::string s : f.xmlHeader.selections){
				Selection sel(s.c_str());
				addSelection(sel);
				activateSelection(s);

				active_sel = new Selection();
				*active_sel = sel;
				break;
			}
			if (f.xmlHeader.compOp!="")
			comp = new CompositeOperation(f.xmlHeader.compOp.c_str());
		}
	
	/*	else {
			Layer l(f.Arr(), f.Width(), f.Height(), t);
			arr.push_back(l);
			xmlHeader.layers.push_back(fname);
		}*/
	
	catch (FileTypeException fte) {
		std::cout << fte;
	}															//Fatalne greske: Ne postoji trazeni fajl ili nije adekvatno formatiran
	catch (InputException ie) {
		std::cout << ie;
	}

}

void Image::addLayer(std::string fname, int t)
{	
	try {
		Formater f(fname);

		Layer l(f.Arr(), f.Width(), f.Height(), t);

		xmlHeader.layers.push_back(fname);

		if (header.size() == 0) header = f.Header();

		if (f.Width() < width || f.Height() < height) {
				l.resize(width, height);
		}
		if (f.Width() > width || f.Height() > height) {

			height = f.Height();
			width = f.Width();
			header = f.Header();

			std::for_each(arr.begin(), arr.end(), [this](Layer& l) {l.resize(width, height); });

		}
		arr.push_back(l);
	}
	catch (FileTypeException ft) {
		std::cout << ft;
	}
	catch (InputException ex) {
		std::cout << ex;
	}
}

void Image::saveAs(const char * fname)
{
	Formater f(imageCalculate(), header, width, height, xmlHeader);
	f.write(fname);
}

std::vector<Pixel> Image::imageCalculate()
{
	std::vector<std::pair<Pixel,double>> pom;		//Pomocni vektor cuva piksele i informaciju koliko "providnosti" je ostalo za datu poziciju (od 0-1)
	std::vector<Pixel> ret;

	Pixel p(0, 0, 0, 0);
	std::pair<Pixel, double> pair(p, 1);
	for (int i = 0; i < width*height; i++) {
		pom.push_back(pair);
	}

	int R, G, B;
	double A;

	for(Layer& l : arr)
	{
		if (!l.isActive() || l.Trancparency()==0) continue;
		int i = -1;
		for(Pixel& p : l.Pixels()) {
			++i;
			double t = pom[i].second;
			if (t == 0) continue;					//Ako je istrosena providnost za datu poziciju, piksel se preskace
			double prov = t * l.Trancparency() / 100;			//Providnost sloja
			A = pom[i].first.Alpha() + (1 - pom[i].first.Alpha())*p.Alpha();
			A *= prov;
			t -= prov * A;
			pom[i].second = t;
			if (A == 0) continue;				//Ako je piksel potpuno providan preskace se

			R = (pom[i].first.Red()*pom[i].first.Alpha() / A) + p.Red()*(1 - pom[i].first.Alpha())*p.Alpha() / A;
			G = (pom[i].first.Green()*pom[i].first.Alpha() / A) + p.Green()*(1 - pom[i].first.Alpha())*p.Alpha() / A;
			B = (pom[i].first.Blue()*pom[i].first.Alpha() / A) + p.Blue()*(1 - pom[i].first.Alpha())*p.Alpha() / A;

			Pixel px(prov*R, prov*G, prov*B, A);
			pom[i].first = px;
		}
	}
	for (std::pair<Pixel, double> pr : pom) {
		ret.push_back(pr.first);
	}
	return ret;
}

void Image::saveSeparateLayers()
{
	int i = 0;
	for (Layer l : arr) {
		Formater form(l.getPixels(), header, width, height, xmlHeader);
		form.write(xmlHeader.layers[i++].c_str());
	}
}

void Image::operation(std::string op, int el)
{
	for(Layer& l:arr){
		if (l.isActive())
			l.operation(op, el, active_sel, *comp);							//Operacije se obavljaju nad svakim aktivnim slojem
	};
}

void Image::fillSelection(int red, int green, int blue)
{
	if (active_sel != nullptr) {
		std::for_each(arr.begin(), arr.end(), [this, red, green, blue](Layer& l) {
			if (l.isActive())
				l.fillSelection(active_sel, red, green, blue); });
	}
}

Image::~Image()
{
	delete active_sel;
	delete comp;
}

