#pragma once
#include <fstream>
#include <iostream>
#include <vector>
#include "Exceptions.h"

class Pixel
{
	int red;
	int green;
	int blue;
	double alpha;
public:
	Pixel(int r, int g, int b, int a) :red(r), green(g), blue(b) {
		alpha = a / 255;
	};
	Pixel(int r, int g, int b, double a) :red(r), green(g), blue(b), alpha(a) {};
	~Pixel() {};
	int Red() const { return red; }
	int Blue() const { return blue; }
	int Green() const { return green; }
	double Alpha()const { return alpha; }
	void setRed(int r) { red = r; }
	void setGreen(int g) { green = g; }
	void setBlue(int b) { blue = b; }
};
