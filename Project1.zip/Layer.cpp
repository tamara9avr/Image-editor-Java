#include "Layer.h"


void Layer::resize(int w, int h)
{
	Pixel pom(0, 0, 0, 0);
	int dif = w - width;
	if (dif>0) {
		int i = 0,k=0;
		do{
			i++;
			int pos = i * width + k;
			for (int j = 0; j < dif; j++) {
				pixels.insert(pixels.begin() + pos, pom);
			}
			k += dif;
		} while (i != height);
		width = w;
	}
	
	dif = h - height;
	if (dif>0) {
		for (int j = 0; j < dif*w; j++) {
				pixels.push_back(pom);
		}
		height = h;
	}
}

void Layer::operation(std::string s, int e, Selection* sel, CompositeOperation comp) {
	if (sel == nullptr) {
		for (Pixel& p : pixels) {
			Operations op(s, p, e, comp);
		}
	}
	else {
		for (std::pair<std::pair<int, int>,bool> i : sel->Map()) {				//Prolazi kroz aktivne piksele, ne kroz celu sliku.
			int pos = i.first.first + (height - (i.first.second + 1))*width;
			if (pos < width*height)
			Operations op(s, pixels[pos], e,comp);
		}
	}
}

void Layer::fillSelection(Selection * sel, int red, int green, int blue)
{
	for (std::pair<std::pair<int, int>, bool> i : sel->Map()) {
		int pos = i.first.first*width + i.first.second;
		if (pos < width*height) {
			pixels[pos].setRed(red);
			pixels[pos].setGreen(green);
			pixels[pos].setBlue(blue);
		}
	}
}

Layer::~Layer()
{
}