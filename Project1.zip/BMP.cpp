#include "BMP.h"

BMP::BMP(std::string fname)
{
		std::ifstream image(fname, std::ios::binary);
		if (!image) throw InputException();
		else {
			uint16_t id;
			image.read((char *)&id, 2);
			if (id != 0x4D42) throw FileTypeException();
			image.read((char*)&size_file, 4);
			uint32_t res;								//Promenljive res[i] koriste se za citanje podataka koji nisu od znacaja za manipulaciju slikom.
			image.read((char*)&res, 4);
			image.read((char*)&off, 4);
			uint32_t dib;
			image.read((char*)&dib, 4);
			image.read((char*)&width, 4);
			image.read((char*)&height, 4);
			uint16_t res1;
			image.read((char*)&res1, 2);
			image.read((char*)&bpp, 2);		
			image.read((char*)&res, 4);
			image.read((char*)&size_image, 4);
			image.seekg(off, image.beg);
			if (bpp == 32) {
				while (!image.eof()) {
					uint8_t alpha;
					uint8_t blue;
					uint8_t green;
					uint8_t red;
					image.read((char*)&blue, 1);
					image.read((char*)&green, 1);
					image.read((char*)&red, 1);
					image.read((char*)&alpha, 1);
					Pixel p(red, green, blue, alpha);
					arr.push_back(p);
				}
				arr.erase(arr.end() - 1);
			}
			else {
				if (bpp == 24) {
					int i = 0;
					while (!image.eof()) {
						if ((++i % width != 1) || (i==1)) {
							uint8_t blue;
							uint8_t green;
							uint8_t red;
							image.read((char*)&blue, 1);
							image.read((char*)&green, 1);
							image.read((char*)&red, 1);
							Pixel p(red, green, blue, 255);
							arr.push_back(p);
						}
						else {
							uint8_t padd;							//citanje paddinga
							for (int j = 0; j < (width % 4); j++)
								image.read((char*)&padd, 1);
							i = 0;
						}
					}
					arr.erase(arr.end() - 1);
				}
				image.close();
			}
		}
}

void BMP::write(const char* fname) {
	std::ofstream image(fname, std::ios::binary);
	uint16_t id = 0x4D42;
	image.write((char*)&id, 2);
	image.write((char*)&size_file, 4);
	uint32_t res = 0x00;
	image.write((char*)&res, 4);
	image.write((char*)&off, 4);
	uint32_t dib = 40;
	image.write((char*)&dib, 4);
	image.write((char*)&width, 4);
	image.write((char*)&height, 4);
	uint16_t res1 = 1;
	image.write((char*)&res1, 2);
	image.write((char*)&bpp, 2);
	uint32_t res2 = 0;
	image.write((char*)&res2, 4);
	image.write((char*)&size_image, 4);
	uint32_t res3 = 2835;
	image.write((char*)&res3, 4);
	image.write((char*)&res3, 4);
	res3 = 0;
	image.write((char*)&res3, 4);
	image.write((char*)&res3, 4);
	image.seekp(off, image.beg);
	if (bpp == 32) {
		for (Pixel i : arr) {
			uint8_t el = i.Blue();
			image.write((char*)&el, 1);
			el = i.Green();
			image.write((char*)&el, 1);
			el = i.Red();
			image.write((char*)&el, 1);
			el = i.Alpha()*255;
			image.write((char*)&el, 1);
		}
	}
	else {
		if (bpp == 24) {
			int i = 0;
			for (int p = 0; p < arr.size();) {
				if ((++i % width != 1) || (i == 1)) {
					uint8_t el = arr[p].Blue();
					image.write((char*)&el, 1);
					el = arr[p].Green();
					image.write((char*)&el, 1);
					el = arr[p++].Red();
					image.write((char*)&el, 1);
				}
				else {
					uint8_t padd = 0;
					for (int j = 0; j < (width % 4); j++)
						image.write((char*)&padd, 1);
					i = 0;
				}
			}
			uint8_t padd = 0;
			for (int j = 0; j < (width % 4); j++)
				image.write((char*)&padd, 1);
		}
	}
	image.close();
}