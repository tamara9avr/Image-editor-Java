#include "Formater.h"
#include "Layer.h"

class Image
{
	XMLHeader xmlHeader;
	std::vector<int> header;			//Zaglavlje sadrzi informacije potrebne za cuvanje slike u ponudjenim formatima
	int height;
	int width;
	std::vector<Layer> arr;				
	std::vector<Selection> sel;
	Selection* active_sel=nullptr;		//Moze postojati samo jedna aktivna selekcija
	CompositeOperation* comp=nullptr;

public:

	Image(const char *fname, int t);
	Image(int w, int h) :width(w), height(h) {
		Layer l(w, h);
		arr.push_back(l);
	}

	Image() {};
	
	void addLayer(std::string fname, int t);
	void addLayer() {					//Dodavanje providnog sloja
		Layer l(width, height);
		arr.push_back(l);
	}
	void activateLayer(int i) {
		arr[i].activate();
	}
	void deactivateLayer(int i) {
		arr[i].deactivate();
	}
	void deleteLayer(int i) { arr.erase(arr.begin() + i); }

	void saveSeparateLayers();

	void operation(std::string op, int el);

	void addSelection(std::string name, std::vector<Rectangle> arr) {
		Selection s(name, arr);
		sel.push_back(s);
		if (active_sel == nullptr) active_sel=new Selection(s);
	}
	void addSelection(Selection s) {
		sel.push_back(s);
	}
	void exportSelection(std::string fname, std::string name) {
		for (Selection& s : sel) {
			if (s.Name() == name) {
				s.exportSelection(fname);
				xmlHeader.selections.push_back(fname);
				return;
			}
		}
	}
	void fillSelection(int red, int green, int blue);
	void activateSelection(std::string name) {
		for (Selection& s : sel) {
			if (s.Name() == name) {
				s.activate();
				active_sel = new Selection(s);
				return;
			}
		}
	}
	void deactivateSelecton() {active_sel = nullptr;}
	void deleteSelection(std::string name) {
		int i;
		for (Selection& s : sel) {
			if (s.Name() == name) {
				if (active_sel == &s) active_sel = nullptr;
				sel.erase(sel.begin() + i);
				return;
			}
			i++;
		}
	}

	int Visina()const { return height; }
	int Sirina()const { return width; }

	void saveAs(const char *fname);
	std::vector<Pixel> imageCalculate();

	std::vector<Layer>::iterator begin() { return arr.begin(); }
	std::vector<Layer>::iterator end() { return arr.end(); }

	void setXML(const char* path) { xmlHeader.compOp = path; }

	void setComp(CompositeOperation c) { comp = new CompositeOperation(c); }

	~Image();
};

