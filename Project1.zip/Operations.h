#pragma once
#include "Pixel.h"
#include<math.h>

class Operations;

class OperationError {
public:
	OperationError() {};
	friend std::ostream& operator<<(std::ostream& os, OperationError oe) {
		return os << "Error:No such function..." << std::endl;
	}
};


class Subtraction  {
	int elem;
	friend class Operations;
public:
	Subtraction(Pixel& pix, int el) :elem(el) {
		int red = pix.Red() - el;
		int green = pix.Green() - el;
		int blue = pix.Blue() - el;
		pix.setRed(red);
		pix.setBlue(blue);
		pix.setGreen(green);
	}
	~Subtraction() {};
};

class InvSubtraction {
	int elem;
	friend class Operations;
public:
	InvSubtraction(Pixel& pix, int el) :elem(el) {
		int red = el - pix.Red();
		int green = el - pix.Green();
		int blue = el - pix.Blue();
		pix.setRed(red);
		pix.setBlue(blue);
		pix.setGreen(green);
	}
	~InvSubtraction() {};
};

class Addition {
	int elem;
	friend class Operations;
public:
	Addition(Pixel& pix, int el) :elem(el) {
		int red = pix.Red() + el;
		int green = pix.Green() + el;
		int blue = pix.Blue() + el;
		pix.setRed(red);
		pix.setBlue(blue);
		pix.setGreen(green);
	}
	~Addition() {};
};

class Multiplication {
	int elem;
	friend class Operations;
public:
	Multiplication(Pixel& pix, int el) :elem(el) {
		int red = pix.Red() * el;
		int green = pix.Green() * el;
		int blue = pix.Blue() * el;
		pix.setRed(red);
		pix.setBlue(blue);
		pix.setGreen(green);
	}
	~Multiplication() {};
};

class Division {
	int elem;
	friend class Operations;
public:
	Division(Pixel& pix, int el) :elem(el) {
		if (elem == 0) {}
		int red = pix.Red() / el;
		int green = pix.Green() / el;
		int blue = pix.Blue() / el;
		pix.setRed(red);
		pix.setBlue(blue);
		pix.setGreen(green);
	}
	~Division() {};
};

class InvDivision {
	int elem;
	friend class Operations;
public:
	InvDivision(Pixel& pix, int el) :elem(el) {
		if (elem == 0) {}
		if (pix.Red() != 0) {
			int red = el / pix.Red();
			pix.setRed(red);
		}
		if (pix.Green() != 0) {
			int green = el / pix.Green();
			pix.setGreen(green);
		}
		if (pix.Blue() != 0) {
			int blue = el / pix.Blue();
			pix.setBlue(blue);
		}

	}
	~InvDivision() {};
};

class Power {
	int elem;
	friend class Operations;
public:
	Power(Pixel& pix, int el) :elem(el) {
		pix.setRed(pow(pix.Red(), elem));
		pix.setBlue(pow(pix.Blue(), elem));
		pix.setGreen(pow(pix.Green(), elem));
	}
	~Power() {};
};

class Logarithm {
	int elem;
	friend class Operations;
public:
	Logarithm(Pixel& pix, int el) :elem(el) {
		pix.setRed(log(pix.Red()));
		pix.setGreen(log(pix.Green()));
		pix.setBlue(log(pix.Blue()));
	}
	~Logarithm() {};
};

class Abs {
public:
	Abs(Pixel& p) {
		p.setRed(abs(p.Red()));
		p.setGreen(abs(p.Green()));
		p.setBlue(abs(p.Blue()));
	}
};

class Minimum {
	int elem;
	friend class Operations;
public:
	Minimum(Pixel& pix, int el) :elem(el) {
		if (pix.Red() > elem) pix.setRed(elem);
		if (pix.Green() > elem) pix.setGreen(elem);
		if (pix.Blue() > elem) pix.setBlue(elem);
	}
	~Minimum() {};
};

class Maximum {
	int elem;
	friend class Operations;
public:
	Maximum(Pixel& pix, int el) :elem(el) {
		if (pix.Red() < elem) pix.setRed(elem);
		if (pix.Green() < elem) pix.setGreen(elem);
		if (pix.Blue() < elem) pix.setBlue(elem);
	}
	~Maximum() {};
};

class Inversion {
	friend class Operations;
public:
	Inversion(Pixel& pix) {
		InvSubtraction inv(pix, 255);
	}
	~Inversion() {};
};

class Gray {
	friend class Operations;
public:
	Gray(Pixel& pix) {
		int ars = (pix.Red() + pix.Blue() + pix.Green()) / 3;
		pix.setRed(ars);
		pix.setGreen(ars);
		pix.setBlue(ars);
	}
	~Gray() {};
};

class BlackWhite {
	friend class Operations;
public:
	BlackWhite(Pixel& pix) {
		int ars = (pix.Red() + pix.Blue() + pix.Green()) / 3;
		if (ars < 127) {
			pix.setRed(0);
			pix.setGreen(0);
			pix.setBlue(0);
		}
		else {
			pix.setRed(255);
			pix.setGreen(255);
			pix.setBlue(255);
		}
	}
	~BlackWhite() {};
};

class CompositeOperation {
	std::vector<std::pair<std::string, int>> op;
public:
	void fun(Pixel& px) {
		Pixel p(px);;
		for (std::pair<std::string, int> par : op) {
			if (par.first == "Substitute") Subtraction sub(p, par.second);
            else if (par.first == "InverseSubstitute") InvSubtraction invsub(p, par.second);
            else if (par.first == "Add") Addition add(p, par.second);
           	else if (par.first == "Multiply") Multiplication mul(p, par.second);
           	else if (par.first == "Divide") Division div(p, par.second);
           	else if (par.first == "InverseDivide") InvDivision invdiv(p, par.second);
           	else if (par.first == "Power") Power pow(p, par.second);
           	else if (par.first == "Logarithm") Logarithm log(p, par.second);
           	else if (par.first == "Minimum") Minimum min(p, par.second);
           	else if (par.first == "Maximum") Maximum max(p, par.second);
           	else if (par.first == "Inverse") Inversion inv(p);
           	else if (par.first == "Gray") Gray gr(p);
           	else if (par.first == "BlackAndWhite") BlackWhite bw(p);
        }
		if (p.Red() > 255) p.setRed(255);
		if (p.Red() < 0) p.setRed(0);
		if (p.Green() > 255) p.setGreen(255);
		if (p.Green() < 0) p.setGreen(0);
		if (p.Blue() > 255) p.setBlue(255);
		if (p.Blue() < 0) p.setBlue(0);
		px = p;
	}

	CompositeOperation(const char* fname) {
		std::ifstream file(fname);
		while(!file.eof()) {
			char s[50];
			int e;
			file >> s >> e;
			std::pair<std::string, int> pom(s, e);
			op.push_back(pom);
		}
	}

	CompositeOperation(std::vector<std::pair<std::string, int>> arr) :op(arr) {};

	void exportCompOp(const char * fname) {
		std::ofstream file(fname);
		for (std::pair<std::string, int> s : op) {
			std::string n = s.first;
			file << n.c_str();
			file << " " << s.second << std::endl;
		}
	}
};

class Operations
{
	CompositeOperation* comp=nullptr;
public:
	Operations(std::string op, Pixel& p, int e, CompositeOperation c) {
		try {
			comp = new CompositeOperation(c);
			if (op == "Substitute") Subtraction sub(p, e);
			else if (op == "InverseSubstitute") InvSubtraction invsub(p, e);
			else if (op == "Add") Addition add(p, e);
			else if (op == "Multiply") Multiplication mul(p, e);
			else if (op == "Divide") Division div(p, e);
			else if (op == "InverseDivide") InvDivision invdiv(p, e);
			else if (op == "Power") Power pow(p, e);
			else if (op == "Logarithm") Logarithm log(p, e);
			else if (op == "Minimum") Minimum min(p, e);
			else if (op == "Maximum") Maximum max(p, e);
			else if (op == "Inverse") Inversion inv(p);
			else if (op == "Gray") Gray gr(p);
			else if (op == "BlackAndWhite") BlackWhite bw(p);
			else if (op == "Composite") comp->fun(p);
			else throw OperationError();
		}
		catch (OperationError oe) {
			std::cout << oe;
		}
	};
	~Operations() { delete comp; };
};
