#pragma once
#include "Exceptions.h"
#include <string>
#include "Rectangle.h"
#include <map>
#include <fstream>
#include <regex>


class Selection
{
	std::string name;
	std::vector<Rectangle> arr;
	std::map<std::pair<int, int>, bool> map;			//active pixels in selection
	bool active = false;

public:

	Selection(std::string n, std::vector<Rectangle> r);
	Selection() {};
	Selection(std::string);
	
	void deactivate() { active = false; }
	void activate() { active = true; }

	~Selection();

	std::vector<Rectangle>::iterator begin() { return arr.begin(); }
	std::vector<Rectangle>::iterator end() { return arr.end(); }

	std::map<std::pair<int, int>, bool> Map() { return map; }
	std::string Name() { return name; }

	void exportSelection(std::string fname);
};

