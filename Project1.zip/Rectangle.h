#pragma once
#include <vector>

class Rectangle
{
	int heigth;
	int width;
	std::pair<int, int> position;

public:

	Rectangle(std::pair<int, int> p, int w, int h) :position(p), heigth(h), width(w) {};

	std::pair<int, int> Position() { return position; }
	int Height() { return heigth; }
	int Width() { return width; }

	~Rectangle() {};
};

