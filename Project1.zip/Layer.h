#pragma once
#include "Pixel.h"
#include "Operations.h"
#include "Selection.h"
#include <algorithm>


class Layer
{
	std::vector<Pixel> pixels;
	int height;
	int width;
	int trancparency;
	bool activiti = true;

public:

	Layer(int w, int h) :height(h), width(w), trancparency(0) {};
	Layer(std::vector<Pixel> arr, int w, int h, int t) :pixels(arr), width(w), height(h), trancparency(t) {};

	void resize(int w, int h);

	int Trancparency() { return trancparency; }
	std::vector<Pixel> Pixels() { return pixels; }

	std::vector<Pixel> getPixels() { return pixels; }

	void activate() { activiti = true; }
	void deactivate() { activiti = false; }

	bool isActive() { return activiti; }

	void fillSelection(Selection*, int, int, int);
	void operation(std::string s, int e, Selection* sel, CompositeOperation comp);

	std::vector<Pixel>::iterator begin() { return pixels.begin(); }
	std::vector<Pixel>::iterator end() { return pixels.end(); }

	~Layer();
};
